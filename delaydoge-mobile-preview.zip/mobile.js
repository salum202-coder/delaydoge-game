// Screen flow around the playable prototype. Progress remains in the existing save.
const shell=document.createElement('section');
shell.id='lobby';
shell.innerHTML=`<header class="lobby-header"><span class="badge">مركز التوصيل</span><button id="lobbyCast">المندوبون</button></header><div class="wordmark" dir="ltr">DELAY<span>DOGE</span><small>POSTAL ADVENTURES</small></div><div class="depot"><div class="depot-sign">مستودع الشحنات المتأخرة</div><div class="warehouse-window"></div><div class="shelves">📦 📦 📦<br>📦 📦 📦</div><img class="lobby-cat" src="assets/expresscat-cutout-v2.png" alt="Express Cat مندوب التوصيل"><div class="dialogue">الشحنة جاهزة…<br>وين DelayDoge؟</div><div class="parcel-stack">📦</div></div><div class="dispatch"><span class="badge">مهمتك القادمة</span><h1>شحنة صغيرة، مغامرة كبيرة</h1><p>طابق قطع البريد وافتح الطريق للتوصيل.</p><button id="prepare" class="play-button"></button><button id="resume" hidden>متابعة الشحنة الحالية</button></div><nav class="lobby-nav"><button id="lobbyMap">⌖<span>مسار التوصيل</span></button><button class="active" disabled>⌂<span>المقر</span></button><button id="teamCast">♟<span>الفريق</span></button></nav>`;
document.body.appendChild(shell);
// Reuse the game's illustrated parcels, with matching line icons for navigation.
document.querySelector('.shelves').innerHTML=Array.from({length:6},()=>sprite(1)).join('');
document.querySelector('.parcel-stack').innerHTML=sprite(7);
const navPaths={lobbyMap:'M12 21s7-6 7-12a7 7 0 1 0-14 0c0 6 7 12 7 12Z M15 9a3 3 0 1 1-6 0 3 3 0 0 1 6 0',teamCast:'M16 21v-3a4 4 0 0 0-8 0v3 M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0 M20 12a3 3 0 0 1 2 3v5 M4 12a3 3 0 0 0-2 3v5',home:'m3 11 9-8 9 8 M5 10v11h14V10 M10 21v-7h4v7'};
for(const [id,path] of Object.entries(navPaths)){const button=id==='home'?document.querySelector('.lobby-nav .active'):$(id);button.firstChild.remove();button.insertAdjacentHTML('afterbegin',`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${path}"/></svg>`);}
const prep=document.createElement('div');prep.id='preparation';prep.className='result';prep.hidden=true;
prep.innerHTML=`<div class="result-card prep-card"><button id="closePrep" class="close-button" aria-label="إغلاق">×</button><span class="badge">انطلاق الشحنة</span><h2 id="prepTitle"></h2><p>مهمتك في هذه الجولة</p><div class="goal-cards"><div>${sprite(1)}<b id="prepParcels"></b><small>قطع بريد</small></div><div>${sprite(7)}<b id="prepCrates"></b><small>صناديق مختومة</small></div></div><p id="prepMoves"></p><label for="courier">اختر مندوب التوصيل</label><select id="courier"><option value="delaydoge">DelayDoge · صاروخ إضافي</option><option value="expresscat">Express Cat · حركة إضافية</option></select><div class="included-tools">أدوات الجولة مشمولة: صاروخ · ختم · تحويلة</div><button id="launch" class="play-button">ابدأ التوصيل</button></div>`;
document.body.appendChild(prep);
const back=document.createElement('button');back.id='backHome';back.textContent='‹ المقر';document.querySelector('.top').prepend(back);
let inRound=false;
function home(){document.body.classList.add('at-home');$('prepare').textContent=`العب المرحلة ${stage}`;$('resume').hidden=!inRound;}
function prepare(){ $('prepTitle').textContent=`المرحلة ${stage}`;$('prepParcels').textContent=targetParcels();$('prepCrates').textContent=targetCrates();$('courier').value=character;updatePreparation();prep.hidden=false;}
function updatePreparation(){$('prepMoves').textContent=`${stageMoves()+($('courier').value==='expresscat'?1:0)} حركة لإتمام التوصيل`;}
$('courier').onchange=updatePreparation;
$('prepare').onclick=prepare;$('closePrep').onclick=()=>prep.hidden=true;
$('launch').onclick=()=>{character=$('courier').value;localStorage.setItem('delaydoge.character',character);reset();prep.hidden=true;document.body.classList.remove('at-home');inRound=true;};
$('backHome').onclick=home;$('resume').onclick=()=>document.body.classList.remove('at-home');
for(const id of ['lobbyCast','teamCast'])$(id).onclick=()=>{renderCast();$('cast').hidden=false;};
$('lobbyMap').onclick=()=>{renderMap();$('map').hidden=false;};
const originalReset=reset;reset=function(){originalReset();if(document.body.classList.contains('at-home')){inRound=false;home();}};
const originalNextStage=nextStage;nextStage=function(){$('result').hidden=true;originalNextStage();inRound=false;home();prepare();};
const previousShowResult=showResult;
showResult=function(){
 previousShowResult();
 if(stage===deliveryLevels.length&&missionComplete()){
  $('resultTitle').textContent='أكملت جميع مراحل النسخة الحالية!';
  $('resultText').textContent=`تم توصيل الشحنة ${stage} — ${score} نقطة. يمكنك إعادة لعب المراحل من مسار التوصيل.`;
  $('resultButton').textContent='العودة إلى المقر';
  $('resultButton').onclick=()=>{$('result').hidden=true;inRound=false;home();};
 }
};
home();
