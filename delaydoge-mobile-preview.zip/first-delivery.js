// Nonblocking guidance: it never spends a move or changes the board.
const deliveryGuideKey='delaydoge.firstGuide.v1';
let guideStep=0,guideDismissed=localStorage.getItem(deliveryGuideKey)==='done';
const guideSteps=[
 ['حرّك البريد','اسحب قطعة نحو جارتها، أو اضغط القطعتين. طابق 3 قطع من النوع نفسه؛ التبديل الذي لا يصنع مطابقة لا يستهلك حركة.'],
 ['وين الطرد؟','الطرد بعلامة ؟ هو شحنتك. طابق القطع تحته لينزل؛ لا يمكنك تبديله أو جمعه بمطابقة.'],
 ['المخرج هنا ↓','أنزل الطرد إلى السهم أسفل اللوحة. الصناديق تعيق الطريق؛ في هذه الشحنة لا يلزم فتحها كلها.']
];
const guide=document.createElement('aside');guide.id='deliveryGuide';guide.hidden=true;guide.setAttribute('aria-label','دليل أول شحنة');
guide.innerHTML='<div><strong id="guideTitle"></strong><button id="dismissGuide" aria-label="إخفاء دليل الشحنة">×</button></div><p id="guideText"></p><footer><small id="guidePage"></small><button id="nextGuide">التالي</button></footer>';
document.querySelector('.play-hud').after(guide);
const guideToggle=document.createElement('button');guideToggle.id='guideToggle';guideToggle.textContent='كيف أوصل الطرد؟';guideToggle.hidden=true;guideToggle.type='button';document.querySelector('.mission').appendChild(guideToggle);
function updateDeliveryGuide(){
 const available=stage===1&&lostDeliveryMode&&!ended;
 guide.hidden=!available||guideDismissed;guideToggle.hidden=!available;
 $('board').querySelectorAll('.guide-target').forEach(tile=>tile.classList.remove('guide-target'));
 if(guide.hidden)return;
 $('guideTitle').textContent=guideSteps[guideStep][0];$('guideText').textContent=guideSteps[guideStep][1];
 $('guidePage').textContent=`${guideStep+1} / ${guideSteps.length}`;$('nextGuide').textContent=guideStep===2?'خلّهم ينتظرون… نبدأ!':'التالي';
 const target=guideStep===1?grid.indexOf(5):guideStep===2?59:-1;
 if(target>=0)$('board').children[target]?.classList.add('guide-target');
}
function dismissDeliveryGuide(){guideDismissed=true;localStorage.setItem(deliveryGuideKey,'done');updateDeliveryGuide();}
const guideRender=render;render=function(){guideRender();updateDeliveryGuide();};
$('dismissGuide').onclick=dismissDeliveryGuide;
$('nextGuide').onclick=()=>{if(guideStep===2)dismissDeliveryGuide();else{guideStep++;updateDeliveryGuide();}};
guideToggle.onclick=()=>{guideDismissed=false;guideStep=0;updateDeliveryGuide();};
const guideResult=showResult;showResult=function(){guideResult();updateDeliveryGuide();};
updateDeliveryGuide();
