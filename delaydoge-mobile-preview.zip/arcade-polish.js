// All audio is synthesized locally; nothing downloads or starts before interaction.
let musicEnabled=localStorage.getItem('delaydoge.music')==='on',musicTimer=null,musicStep=0;
function arcadeNote(freq,duration=.12,delay=0,type='sine',volume=.035){
 if(!soundEnabled)return;
 try{audioContext=audioContext||new(window.AudioContext||window.webkitAudioContext)();if(audioContext.state==='suspended')audioContext.resume();const at=audioContext.currentTime+delay,o=audioContext.createOscillator(),g=audioContext.createGain();o.type=type;o.frequency.setValueAtTime(freq,at);g.gain.setValueAtTime(.001,at);g.gain.exponentialRampToValueAtTime(volume,at+.012);g.gain.exponentialRampToValueAtTime(.001,at+duration);o.connect(g).connect(audioContext.destination);o.start(at);o.stop(at+duration+.02);}catch(e){}
}
function arcadeSound(kind,combo=1){
 const notes=kind==='win'?[523,659,784,1047]:kind==='lose'?[392,330,262]:kind==='boost'?[196,392,784]:kind==='invalid'?[180,150]:kind==='match'?[523,659,784].map(n=>n*Math.min(1.5,1+(combo-1)*.1)):[440];
 notes.forEach((n,i)=>arcadeNote(n,kind==='win'?.3:.11,i*.065,kind==='invalid'?'triangle':'sine'));
}
function updateArcadeMusic(){
 clearInterval(musicTimer);musicTimer=null;
 if(!musicEnabled||!soundEnabled||document.hidden)return;
 const melody=[262,330,392,330,294,349,440,349,262,330,523,392,294,349,392,294];
 musicTimer=setInterval(()=>{if(document.hidden)return;arcadeNote(melody[musicStep++%melody.length],.32,0,'triangle',.009);},420);
}
const musicRow=document.createElement('label');musicRow.className='setting-row';musicRow.innerHTML='<span>موسيقى المستودع</span><input id="musicSetting" type="checkbox">';settingsPanel.querySelector('.settings-card').insertBefore(musicRow,helpButton);
const audioNote=document.createElement('p');audioNote.className='audio-note';audioNote.textContent='موسيقى هادئة اختيارية، وأصوات مختلفة للمطابقة والأدوات والنتيجة.';musicRow.after(audioNote);
$('musicSetting').checked=musicEnabled;$('musicSetting').onchange=e=>{musicEnabled=e.target.checked;localStorage.setItem('delaydoge.music',musicEnabled?'on':'off');updateArcadeMusic();};
$('soundSetting').addEventListener('change',updateArcadeMusic);document.addEventListener('visibilitychange',updateArcadeMusic);document.addEventListener('pointerdown',()=>{if(audioContext?.state==='suspended')audioContext.resume();if(musicEnabled&&!musicTimer)updateArcadeMusic();},{passive:true});
const missionBrief=document.createElement('aside');missionBrief.id='missionBrief';missionBrief.innerHTML='<span id="missionBriefText"></span><button id="openArcadeHelp" type="button">كيف ألعب؟</button>';document.querySelector('.board-wrap').before(missionBrief);
$('openArcadeHelp').onclick=()=>{helpPanel.hidden=false;helpPanel.querySelector('.close-button').focus();};
const arcadeToast=document.createElement('div');arcadeToast.id='arcadeToast';arcadeToast.setAttribute('aria-live','polite');document.querySelector('.board-wrap').appendChild(arcadeToast);
let arcadeToastTimer;
function showArcadeToast(title,detail=''){arcadeToast.replaceChildren();const main=document.createElement('span');main.textContent=title;arcadeToast.appendChild(main);if(detail){const sub=document.createElement('small');sub.textContent=detail;arcadeToast.appendChild(sub);}arcadeToast.classList.remove('show');void arcadeToast.offsetWidth;arcadeToast.classList.add('show');clearTimeout(arcadeToastTimer);arcadeToastTimer=setTimeout(()=>arcadeToast.classList.remove('show'),900);}
const polishRender=render;render=function(){polishRender();$('missionBriefText').textContent=lostDeliveryMode?'طابق تحت الطرد ؟ وأنزله إلى السهم ↓':`اجمع ${Math.max(0,targetParcels()-collected)} قطعة بريد وافتح ${Math.max(0,targetCrates()-broken)} صندوقًا`;$('hudMail').parentElement.title=lostDeliveryMode?'الطرد المطلوب إنزاله إلى المخرج':'قطع البريد المتبقية';$('hudCrates').parentElement.title='الصناديق المتبقية';};
let cascadeChain=0;
const polishReplay=replayStep;replayStep=async function(step){if(step.type==='clear'){cascadeChain++;arcadeSound('match',cascadeChain);if(cascadeChain>1)showArcadeToast(cascadeChain>=3?'توصيل أسطوري!':'مطابقة متتالية!',`كومبو ×${cascadeChain}`);}return polishReplay(step);};
const polishEffects=runEffects;runEffects=async function(action){cascadeChain=0;return polishEffects(action);};
const polishPick=pick;pick=async function(i){const a=selected;if(!animating&&!ended&&a!==null&&adjacent(a,i)&&!isGap(i)&&!crates.has(i)&&grid[i]!==5){if(!previewMove(a,i).length){arcadeSound('invalid');showArcadeToast('جرّب اتجاهًا آخر','التبديل يحتاج مطابقة 3 قطع');}else arcadeNote(440,.07);}return polishPick(i);};
const polishBooster=useBooster;useBooster=function(type){if(!animating&&!ended&&boosters[type]>0){arcadeSound('boost');showArcadeToast(type==='rocket'?'صاروخ التوصيل!':type==='stamp'?'فتح الصناديق!':'ترتيب جديد!','الأدوات لا تستهلك حركة');}return polishBooster(type);};
const polishResult=showResult;showResult=function(){const alreadyVisible=!$('result').hidden;polishResult();if(!alreadyVisible)arcadeSound(missionComplete()?'win':'lose');};
$('rocket').title='يمسح صف القطعة المحددة؛ بلا تحديد يختار صفًا';$('stamp').title='يفتح صندوقين أو يخفف أختامهما';$('shuffle').title='يعيد ترتيب القطع دون استهلاك حركة';
render();
