// Authored routes: positions, move budgets and collection goals are independent.
const deliveryLevels=[
 {name:'أول شحنة',note:'افتح صف الصناديق أمام بوابة المستودع.',mail:18,moves:24,boxes:[56,57,58,61,62,63]},
 {name:'ممر الفرز',note:'اكسر عمودي الصناديق وافتح الممر الأوسط.',mail:24,moves:24,boxes:[25,30,33,38,41,46,49,54]},
 {name:'الشحنة المختومة',note:'الهدف هو فك جميع الأختام؛ جمع القطع ليس مطلوبًا.',mail:0,moves:26,boxes:[18,19,20,21,26,29,34,37,42,45]},
 {name:'ساعة الذروة',note:'اجمع البريد وافتح الحاجز المتعرج.',mail:32,moves:27,boxes:[24,25,26,34,35,36,44,45,46,54,55,63]},
 {name:'التسليم الكبير',note:'افتح بوابة الشحن باستخدام القطع الخاصة.',mail:38,moves:34,boxes:[16,23,24,31,32,39,40,47,48,55,56,57,62,63]},
 {name:'الجسر البريدي',note:'جزيرتان يصل بينهما جسر: افتح صناديق الطرفين باستخدام المطابقات والصواريخ.',mail:42,moves:32,boxes:[0,7,8,15,16,23,40,47,48,55,56,63]},
 {name:'خزنة الأختام',note:'فك الأختام الستة عشر؛ الصواريخ تختصر الطريق.',mail:0,moves:26,boxes:[18,19,20,21,26,29,34,37,42,43,44,45,50,51,52,53]},
 {name:'مسار سريع',note:'اعبر عنق الساعة الرملية وافتح حواجز البريد في الأعلى والأسفل.',mail:50,moves:31,boxes:[8,9,10,13,14,15,18,21,42,45,48,49,50,53,54,55]},
 {name:'الممر المزدوج',note:'شغّل القطع الخاصة للوصول إلى صناديق الممرين.',mail:54,moves:34,boxes:[0,7,8,15,16,23,24,31,32,39,40,47,48,55,56,63]},
 {name:'الشحنة الذهبية',note:'الشحنة الذهبية محمية بقفلين لكل صندوق: ② ثم ①. طابق بجانب الصناديق مرتين، أو افتحها بالختم مباشرة. اجمع 60 قطعة وافتح الصناديق الـ18 خلال 30 حركة.',mail:60,moves:30,boxes:[5,6,7,12,15,19,23,26,31,34,39,43,47,52,55,61,62,63]}
];
const levelSpec=()=>deliveryLevels[stage-1];
try{const previousRecords=JSON.parse(localStorage.getItem('delaydoge.records')||'{}');if(previousRecords[5]?.wins>0&&unlocked<6){unlocked=6;localStorage.setItem('delaydoge.unlocked',unlocked);}}catch{}
targetParcels=()=>levelSpec().mail;targetCrates=()=>levelSpec().boxes.length;stageMoves=()=>levelSpec().moves;
makeGrid=function(){specials={};crates=new Set(levelSpec().boxes);grid=Array.from({length:64},(_,i)=>crates.has(i)?null:rand(5));for(let i=0;i<64;i++){if(crates.has(i))continue;while(i%8>=2&&grid[i]===grid[i-1]&&grid[i]===grid[i-2]||i>=16&&grid[i]===grid[i-8]&&grid[i]===grid[i-16])grid[i]=rand(5);}};
const levelRender=render;render=function(){levelRender();const spec=levelSpec();$('missionTitle').textContent=spec.name;$('progress').style.width=((spec.mail?Math.min(collected/spec.mail,1)+Math.min(broken/targetCrates(),1):Math.min(broken/targetCrates(),1))/(spec.mail?2:1)*100)+'%';if(!spec.mail)$('progressText').textContent=`الأختام المفتوحة: ${broken} / ${targetCrates()}`;};
const levelPrepare=prepare;prepare=function(){levelPrepare();$('prepTitle').textContent=`${stage} · ${levelSpec().name}`;$('preparation').querySelector('.prep-card > p').textContent=levelSpec().note;$('prepParcels').parentElement.hidden=!targetParcels();};
$('prepare').onclick=()=>prepare();
renderMap=function(){const host=$('mapGrid');host.innerHTML='';deliveryLevels.forEach((spec,index)=>{const n=index+1,b=document.createElement('button');b.disabled=n>unlocked;b.className=n>unlocked?'locked':n===stage?'current':'';b.innerHTML=`<b>${n>unlocked?'🔒':n}</b><small>${spec.name}</small>`;b.onclick=()=>{stage=n;$('map').hidden=true;reset();prepare();};host.appendChild(b);});};
// Give icons a deliberate round badge instead of exposing atlas corners.
const levelStyle=document.createElement('style');levelStyle.textContent=`.goal-cards .sprite{border-radius:50%;border:2px solid #d9b66f;box-shadow:0 2px 5px #17324844;background-color:#173248}.goal-cards>div{background:linear-gradient(#f4ecd7,#e4d4b2)}.map-grid{grid-template-columns:1fr!important;gap:7px}.map-grid button{display:flex;align-items:center;gap:12px;padding:10px 15px}.map-grid small{font-size:12px;margin:0}.map-grid b{font-size:20px}.prep-card>p{font-size:14px}`;document.head.appendChild(levelStyle);
reset();
