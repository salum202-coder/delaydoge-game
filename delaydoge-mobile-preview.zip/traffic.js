// Detours happen after every third paid move, never after a booster or refresh.
let trafficPaidMoves=0,trafficPreviousMoves=null;
const trafficMake=makeGrid;
makeGrid=function(){trafficMake();trafficPaidMoves=0;trafficPreviousMoves=moves;};
function trafficDetour(){
 const cells=grid.flatMap((c,i)=>c!==null&&c!==5&&!isGap(i)&&!crates.has(i)&&!specials[i]?[i]:[]);
 for(let attempt=0;attempt<100;attempt++){
  const a=cells[rand(cells.length)],b=cells[rand(cells.length)];
  if(a===undefined||b===undefined||grid[a]===grid[b])continue;
  swapTiles(a,b);
  if(!findMatches().length&&legalMoves().length)return true;
  swapTiles(a,b);
 }
 return false;
}
const trafficResolve=resolveMatches;
resolveMatches=function(...args){
 trafficResolve(...args);
 if(stage!==4)return;
 if(trafficPreviousMoves!==null&&moves<trafficPreviousMoves){
  trafficPaidMoves+=trafficPreviousMoves-moves;
  if(trafficPaidMoves%3===0&&moves>0&&(collected<targetParcels()||broken<targetCrates())&&trafficDetour())announceBoard('Traffic Raccoon: تحويلة؟ تحويلة! بدّلنا قطعتين بدون حركة إضافية.');
 }
 trafficPreviousMoves=moves;
};
const trafficRender=render;
render=function(){trafficRender();if(stage!==4)return;for(const i of crates){const tile=$('board').children[i];tile.innerHTML='<span class="traffic-cone" aria-hidden="true">🚧</span>';tile.setAttribute('aria-label','حاجز مرور: افتحه بمطابقة بجانبه أو بأداة');}$('progressText').textContent=`البريد ${Math.min(collected,targetParcels())}/${targetParcels()} · الحواجز ${broken}/${targetCrates()} · التحويلة بعد ${3-trafficPaidMoves%3} حركات`;};
const trafficPaint=paintFrame;
paintFrame=function(state){trafficPaint(state);if(stage===4)for(const i of state.crates)$('board').children[i].innerHTML='<span class="traffic-cone" aria-hidden="true">🚧</span>';};
deliveryLevels[3].name='تحويلات Traffic Raccoon';
deliveryLevels[3].note='الراكون أغلق الطريق! افتح الحواجز واجمع البريد. كل 3 حركات ناجحة يبدّل قطعتين عاديتين؛ الأدوات لا تقدّم عداد التحويلة.';
