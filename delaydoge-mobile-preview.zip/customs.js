// Customs crates require two hits. The stamp bypasses the inspection lock.
let customsHealth={},customsStamp=false,goldenLocks=false;
const hasInspectionLocks=()=>stage===3||(stage===10&&goldenLocks);
const customsMake=makeGrid;
makeGrid=function(){customsMake();goldenLocks=stage===10;customsHealth=hasInspectionLocks()?Object.fromEntries([...crates].map(i=>[i,2])):{};};
const customsClear=clearTiles;
clearTiles=function(indices,combo=1){
 const before=new Set(crates);
 customsClear(indices,combo);
 if(!hasInspectionLocks())return;
 for(const i of before)if(!crates.has(i)){
  const hp=customsHealth[i]??2;
  if(hp>1&&!customsStamp){crates.add(i);grid[i]=null;customsHealth[i]=hp-1;broken--;score-=20;}
  else delete customsHealth[i];
 }
};
const customsTool=useBooster;
useBooster=function(type){customsStamp=type==='stamp';try{return customsTool(type);}finally{customsStamp=false;}};
const customsRender=render;
render=function(){customsRender();if(!hasInspectionLocks())return;for(const i of crates){const tile=$('board').children[i];const hp=customsHealth[i]??2;tile.insertAdjacentHTML('beforeend',`<span class="customs-lock">${hp===2?'②':'①'}</span>`);tile.setAttribute('aria-label',`صندوق مختوم: ${hp} ضربة متبقية`);}if(stage===3)$('progressText').textContent=`تصاريح الجمارك: ${broken} / ${targetCrates()}`;};
deliveryLevels[2].name='حاجز Customs Boss';
deliveryLevels[2].note='Customs Boss: وين الأوراق؟ كل صندوق يحتاج ضربتين بجانبه أو بالصاروخ. الختم يفتح الصندوق مباشرة. افتح جميع الصناديق.';
const customsPrepare=prepare;
prepare=function(){customsPrepare();if(stage===3)$('preparation').querySelector('.included-tools').textContent='Customs Boss: الختم ناقص… ارجع بعدين! · استخدم الختم لتجاوز القفل.';else $('preparation').querySelector('.included-tools').textContent='أدوات الجولة مشمولة: صاروخ · ختم · تحويلة';};
