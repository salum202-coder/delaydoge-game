const playStyle=document.createElement('link');playStyle.rel='stylesheet';playStyle.href='play-screen.css';document.head.appendChild(playStyle);
const hud=document.createElement('section');hud.className='play-hud';
hud.innerHTML=`<div class="move-counter"><small>الحركات</small><strong id="hudMoves"></strong></div><div class="delivery-goals"><small>المتبقي للتوصيل</small><div><span>${sprite(1)}<b id="hudMail"></b></span><span>${sprite(7)}<b id="hudCrates"></b></span></div></div><img id="hudCourier" alt="مندوب الجولة">`;
document.querySelector('.board-wrap').before(hud);
const feedback=document.createElement('div');feedback.className='play-feedback';feedback.setAttribute('aria-live','polite');document.querySelector('.app').appendChild(feedback);
const baseRender=render;render=function(){baseRender();$('hudMoves').textContent=moves;$('hudMail').textContent=Math.max(0,targetParcels()-collected);$('hudCrates').textContent=Math.max(0,targetCrates()-broken);$('hudCourier').src=`assets/${character==='expresscat'?'expresscat-cutout-v2':'delaydoge-cutout-v2'}.png`;hud.classList.toggle('urgent',moves<=5);};
let animating=false;
const reduced=()=>document.body.classList.contains('reduce-motion')||window.matchMedia('(prefers-reduced-motion: reduce)').matches;
async function animateTile(tile,frames,duration){if(!tile||reduced()||!tile.animate)return;await tile.animate(frames,{duration,easing:'ease-in-out'}).finished;}
const basePick=pick;
pick=async function(i){
 if(animating||ended||moves<=0||crates.has(i))return;
 const a=selected;
 if(a===null||!adjacent(a,i)){basePick(i);return;}
 animating=true;document.querySelector('.app').classList.add('resolving');
 try{
  const first=$('board').children[a],second=$('board').children[i];
  const r=first.getBoundingClientRect(),s=second.getBoundingClientRect();
  const dx=s.left-r.left,dy=s.top-r.top;
  await Promise.all([animateTile(first,[{transform:'none'},{transform:`translate(${dx}px,${dy}px)`}],160),animateTile(second,[{transform:'none'},{transform:`translate(${-dx}px,${-dy}px)`}],160)]);
  const matched=previewMove(a,i);
  if(matched.length){await Promise.all(matched.map(n=>animateTile($('board').children[n],[{filter:'brightness(1)'},{filter:'brightness(2.2)',transform:'scale(1.15)'},{opacity:0,transform:'scale(.35)'}],190)));}
  else await Promise.all([animateTile(first,[{transform:`translate(${dx}px,${dy}px)`},{transform:'none'}],140),animateTile(second,[{transform:`translate(${-dx}px,${-dy}px)`},{transform:'none'}],140)]);
  const oldScore=score;basePick(i);
  if(matched.length){tone(620,.12);feedback.textContent=`+${score-oldScore} · توصيل رائع!`;feedback.classList.remove('visible');void feedback.offsetWidth;feedback.classList.add('visible');await Promise.all([...$('board').children].map(t=>animateTile(t,[{opacity:.5,transform:'translateY(-7px)'},{opacity:1,transform:'none'}],180)));}
 }finally{animating=false;document.querySelector('.app').classList.remove('resolving');}
};
// Prevent other actions from changing the board during the short swap animation.
document.querySelector('.app').addEventListener('click',e=>{if(animating){e.stopImmediatePropagation();e.preventDefault();}},true);
function fitPlayScreen(){
 if(document.body.classList.contains('at-home'))return;
 const app=document.querySelector('.app');
 app.style.width=Math.min(440,document.documentElement.clientWidth)+'px';
 const board=$('board');const overhead=app.getBoundingClientRect().height-board.getBoundingClientRect().height;
 const available=(window.visualViewport?.height||window.innerHeight)-overhead-12;
 app.style.width=Math.max(200,Math.min(440,document.documentElement.clientWidth,available+36))+'px';
}
new MutationObserver(()=>requestAnimationFrame(fitPlayScreen)).observe(document.body,{attributes:true,attributeFilter:['class']});
window.addEventListener('resize',fitPlayScreen);window.visualViewport?.addEventListener('resize',fitPlayScreen);playStyle.onload=fitPlayScreen;
render();

