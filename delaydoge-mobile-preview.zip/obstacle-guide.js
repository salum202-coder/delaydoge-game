// Explain the active obstacle beside the goal, and in the pre-level briefing.
const obstacleRender=render;
render=function(){obstacleRender();const brief=$('missionBriefText');if(hasInspectionLocks()&&crates.size)brief.textContent+= ' · الصندوق ٢ يحتاج ضربتين بجانبه؛ الختم يفتحه مباشرة.';if(stage===5&&complaints.size)brief.textContent+=` · أزل ${complaints.size} أوراق شكوى ! بمطابقة القطعة المغطاة.`;for(const [i,hp] of Object.entries(customsHealth)){const tile=$('board').children[Number(i)];if(tile&&crates.has(Number(i)))tile.setAttribute('aria-label',`صندوق مختوم يحتاج ${hp===1?'ضربة':'ضربتين'}؛ طابق بجانبه أو استخدم الختم`);}};
const obstaclePrepare=prepare;
prepare=function(){obstaclePrepare();const card=$('preparation').querySelector('.prep-card');card.querySelector('.inspection-explanation')?.remove();if(stage!==3&&stage!==10)return;const rule=document.createElement('aside');rule.className='inspection-explanation';rule.innerHTML='<strong>كيف أفتح صندوق ٢؟</strong><div><span>٢</span><b>← مطابقة بجانبه ←</b><span>١</span><b>← مطابقة ثانية ←</b><span>✓</span></div><p>كل مطابقة بجانب الصندوق تزيل ختمًا واحدًا. أداة الختم تفتح الصندوق مباشرة دون استهلاك حركة.</p>';card.querySelector('.included-tools').before(rule);};
const obstacleStyle=document.createElement('style');obstacleStyle.textContent='.inspection-explanation{background:#1e1038;border:1px solid #e7bd66;border-radius:13px;padding:12px;margin:12px 0;color:#ffe8a6;text-align:right}.inspection-explanation>div{display:flex;align-items:center;justify-content:center;gap:6px;direction:rtl;margin:10px 0}.inspection-explanation span{display:grid;place-items:center;width:29px;height:29px;border:2px solid #e7bd66;border-radius:8px;font-size:21px}.inspection-explanation b{font-size:10px}.inspection-explanation p{font-size:12px;line-height:1.6;margin:0}';document.head.appendChild(obstacleStyle);
render();
const prepFitStyle=document.createElement('style');
prepFitStyle.textContent=`
#preparation{padding:12px}
#preparation .prep-card{box-sizing:border-box;width:min(520px,100%);max-height:calc(100svh - 24px);padding:20px 24px;scrollbar-width:thin;scrollbar-color:#ab81ce #25133f}
#preparation .prep-card h2{font-size:26px;margin:8px 0}
#preparation .prep-card>p{font-size:13px;line-height:1.5;margin:0 0 10px}
#preparation .goal-cards{margin:12px 0;gap:10px}
#preparation .goal-cards>div{padding:8px}
#preparation .goal-cards .sprite{width:44px;height:44px;background-size:352px 44px}
#preparation .goal-cards b{font-size:25px}
#preparation .prep-card label{margin:8px 0 4px}
#preparation .prep-card select{padding:8px;font-size:14px}
#preparation .inspection-explanation{padding:10px;margin:10px 0}
#preparation .inspection-explanation>div{margin:7px 0}
#preparation .included-tools{margin:8px 0;font-size:11px}
#preparation #launch{position:sticky;bottom:0;z-index:2;min-height:46px;box-shadow:0 0 0 6px #25133f;margin-top:6px}
@media(max-height:700px){#preparation .prep-card{padding:14px 20px}#preparation .prep-card h2{font-size:22px}#preparation .goal-cards .sprite{width:34px;height:34px;background-size:272px 34px}#preparation .goal-cards{margin:8px 0}#preparation .goal-cards b{font-size:22px}}
`;
document.head.appendChild(prepFitStyle);
