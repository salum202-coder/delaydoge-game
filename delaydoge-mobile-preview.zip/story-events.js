// Queue reactions during resolution, then show them after the board settles.
let pendingReaction=null;
function queueReaction(text,priority=1){if(!pendingReaction||priority>pendingReaction.priority)pendingReaction={text,priority,stage};}
const reactionMake=makeGrid;
makeGrid=function(){pendingReaction=null;reactionMake();};
const reactionClear=clearTiles;
clearTiles=function(...args){
 const boxes=crates.size,papers=complaints.size,health={...customsHealth};
 reactionClear(...args);
 if(stage===3){
  if(boxes>0&&!crates.size)queueReaction('Customs Boss: تمت الموافقة… أخيرًا. · DelayDoge: قلت لك، تأخير رسمي.',3);
  else if(crates.size<boxes)queueReaction('Customs Boss: تصريح واحد جاهز. لا تتحمّس! · DelayDoge: القهوة جاهزة أيضًا.',2);
  else if(Object.keys(health).some(i=>health[i]===2&&customsHealth[i]===1))queueReaction('Customs Boss: بقي ختم آخر! · DelayDoge: حتى الصندوق يتأخر.',1);
 }
 if(stage===5&&complaints.size<papers){
  if(!complaints.size)queueReaction('Angry Karen: خلاص… بس بكتب تقييم! · DelayDoge: خمس نجوم للتأخير الأسطوري؟',3);
  else if(papers===complaintCells.length)queueReaction('Angry Karen: شكوى واحدة بس؟ والباقي؟ · DelayDoge: بالراحة، وحدة وحدة.',1);
  else if(complaints.size<=2)queueReaction('Angry Karen: لسه أنتظر! · DelayDoge: باقي القليل… تقريبًا.',2);
 }
 if(stage===4&&boxes>0&&!crates.size)queueReaction('Traffic Raccoon: الطريق مفتوح؟ من سمح لكم! · DelayDoge: وصلنا قبل التحويلة التالية.',3);
};
const reactionDrop=breakDrop;
breakDrop=function(){const before=collected;reactionDrop();if(lostDeliveryMode&&before===0&&collected===1)queueReaction('الطرد الضائع: هذا عنواني؟ · DelayDoge: المهم وصلنا!',3);};
function buildReactionDialogue(reaction){
 const box=document.createElement('div');box.id='resultReaction';box.className='result-dialogue';
 box.setAttribute('aria-label','حوار نهاية الشحنة');
 const scene=stageStories[reaction.stage];
 const lines=reaction.text.split(' · ');
 lines.forEach((line,index)=>{
  const row=document.createElement('div');row.className='reaction-row'+(index?' doge-row':'');
  const portrait=document.createElement('div');portrait.className='reaction-portrait';
  const source=index?'assets/delaydoge-cutout-v2.png':scene?.image;
  const divider=line.indexOf(':');
  const name=divider>=0?line.slice(0,divider):index?'DelayDoge':scene?.name||'الطرد الضائع';
  if(source){const img=document.createElement('img');img.src=source;img.alt=name;portrait.appendChild(img);}
  else {portrait.textContent=scene?.icon||'📦';portrait.setAttribute('aria-hidden','true');}
  const bubble=document.createElement('div');bubble.className='reaction-bubble';
  const label=document.createElement('b');label.textContent=name;label.dir='auto';
  const text=document.createElement('p');text.textContent=divider>=0?line.slice(divider+1).trim():line;
  bubble.append(label,text);row.append(portrait,bubble);box.appendChild(row);
 });
 return box;
}
function presentReaction(){
 const reaction=pendingReaction;pendingReaction=null;
 if(!reaction||reaction.stage!==stage)return;
 if(ended){$('resultReaction')?.remove();$('resultText').after(buildReactionDialogue(reaction));}
 else announceBoard(reaction.text);
}
const reactionReset=reset;
reset=function(){pendingReaction=null;$('resultReaction')?.remove();reactionReset();};
const reactionPick=pick;
pick=async function(...args){await reactionPick(...args);presentReaction();};
const reactionBooster=useBooster;
useBooster=async function(...args){await reactionBooster(...args);presentReaction();};
