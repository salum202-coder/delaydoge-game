// Lightweight economy foundation; server sync can replace these local saves later.
let coins=Math.max(0,Number(localStorage.getItem('delaydoge.coins')||0));
let deliveries=Math.max(0,Number(localStorage.getItem('delaydoge.deliveries')||0));
function saveEconomy(){localStorage.setItem('delaydoge.coins',coins);localStorage.setItem('delaydoge.deliveries',deliveries);}
function addCoins(amount){coins+=Math.max(0,Math.floor(amount));saveEconomy();refreshEconomy();}
function refreshEconomy(){document.querySelectorAll('[data-coins]').forEach(el=>el.textContent=coins.toLocaleString('ar-SA'));document.querySelectorAll('[data-deliveries]').forEach(el=>el.textContent=deliveries.toLocaleString('ar-SA'));}
const wallet=document.createElement('div');wallet.className='wallet';wallet.innerHTML='<span class="coin-icon">✦</span><b data-coins></b><small>رصيد التوصيل</small>';
document.querySelector('.lobby-header').appendChild(wallet);
const shopButton=document.createElement('button');shopButton.id='shopButton';shopButton.textContent='المتجر';document.querySelector('.lobby-header').appendChild(shopButton);
const shop=document.createElement('div');shop.id='shopModal';shop.className='result';shop.hidden=true;shop.innerHTML='<div class="result-card shop-card"><button class="close-button" id="closeShop">×</button><span class="badge">متجر الأدوات</span><h2>جهّز شحنتك</h2><p>اشترِ أدوات إضافية بالعملات</p><div class="shop-items"><button data-buy="rocket" data-cost="80">🚀<b>صاروخ</b><small>80 ✦</small></button><button data-buy="stamp" data-cost="60">📮<b>ختم</b><small>60 ✦</small></button><button data-buy="shuffle" data-cost="50">🔀<b>تحويلة</b><small>50 ✦</small></button></div><p id="shopMessage"></p></div>';document.body.appendChild(shop);
function buyBooster(type,cost){if(coins<cost){$('shopMessage').textContent='تحتاج عملات أكثر.';return;}coins-=cost;localStorage.setItem('delaydoge.booster.'+type,String(Number(localStorage.getItem('delaydoge.booster.'+type)||0)+1));saveEconomy();refreshEconomy();refreshShop();$('shopMessage').textContent='تمت الإضافة إلى مخزونك!';}
function refreshShop(){refreshEconomy();shop.querySelectorAll('[data-buy]').forEach(b=>{const count=Math.max(0,Number(localStorage.getItem('delaydoge.booster.'+b.dataset.buy)||0));b.querySelector('.shop-stock').textContent=`للجولة القادمة: ${count}`;b.disabled=coins<Number(b.dataset.cost);b.querySelector('.shop-action').textContent=b.disabled?'الرصيد غير كافٍ':'شراء أداة';});}
shopButton.onclick=()=>{shop.hidden=false;$('shopMessage').textContent='';refreshShop();};$('closeShop').onclick=()=>shop.hidden=true;
shop.querySelector('h2').insertAdjacentHTML('afterend','<div class="shop-balance">رصيدك <b data-coins></b> ✦</div>');
for(const [type,n,label,description] of [['rocket',5,'صاروخ','يمسح صفًا كاملًا'],['stamp',8,'ختم','يفتح صندوقين مختومين'],['shuffle',9,'تحويلة','يعيد ترتيب القطع']]){const b=shop.querySelector(`[data-buy="${type}"]`);b.innerHTML=`${sprite(n)}<b>${label}</b><span class="shop-description">${description}</span><span class="shop-stock"></span><small>${b.dataset.cost} ✦</small><span class="shop-action">شراء أداة</span>`;b.onclick=()=>buyBooster(type,Number(b.dataset.cost));}
$('shopMessage').setAttribute('role','status');
shop.querySelector('.shop-card').insertAdjacentHTML('beforeend','<p class="shop-note">تُضاف مشترياتك عند بدء جولة جديدة.</p>');
const shopStyle=document.createElement('style');shopStyle.textContent='.shop-card{background:linear-gradient(145deg,#5930a1,#251246);border:2px solid #b893ee}.shop-balance{display:inline-flex;gap:8px;padding:8px 18px;border:1px solid #e7b748;border-radius:18px;background:#22133c;color:#ffe096;margin:8px 0 16px}.shop-items button .sprite{display:block;width:58px;height:58px;background-image:url(assets/postal-atlas-v1.png)}.shop-items button{border:2px solid #e0bc6c;box-shadow:0 4px #846126;gap:8px}.shop-description,.shop-stock{font-size:10px;line-height:1.5}.shop-stock{color:#4d3375}.shop-action{background:linear-gradient(#8feb31,#3aaf1e);color:#14370a;padding:6px;border-radius:8px;width:90%;font-size:11px;font-weight:800}.shop-items button:disabled{opacity:.6;cursor:default}.shop-items button:disabled .shop-action{background:#bcc5cd;color:#394652}.shop-note{font-size:11px!important;margin-top:16px!important}';document.head.appendChild(shopStyle);
const gameWallet=document.createElement('div');gameWallet.className='game-wallet';gameWallet.innerHTML='<span class="coin-icon">✦</span><b data-coins></b>';document.querySelector('.top').appendChild(gameWallet);
const econStyle=document.createElement('style');econStyle.textContent=`.wallet,.game-wallet{display:flex;align-items:center;gap:5px;background:#15384fdd;border:1px solid #c9a75e;border-radius:18px;padding:5px 9px;color:#fff1bf;box-shadow:inset 0 1px #fff5}.wallet{position:absolute;top:12px;left:50%;transform:translateX(-50%);font-size:13px}.wallet small{display:none}.coin-icon{color:#ffd05e;font-size:18px;text-shadow:0 1px #673f13}.game-wallet{font-size:12px;margin-inline-start:auto}.game-wallet .coin-icon{font-size:14px}#shopButton{margin-inline-start:auto;padding:6px 11px;background:#f0a51a;border-color:#ffe28a;color:#33200d}.shop-card{position:relative}.shop-card h2{color:#ffd05e}.shop-items{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.shop-items button{display:grid;gap:4px;justify-items:center;padding:12px 4px;background:#f2e6c9;color:#173248;border-radius:14px}.shop-items button:first-child{font-size:25px}.shop-items b{font-size:13px}.shop-items small{font-size:11px}@media(max-height:600px){.wallet{top:6px}.game-wallet{display:none}}`;document.head.appendChild(econStyle);refreshEconomy();
const economyShow=showResult;
let economyRewardPaid=false;
function deliveryReward(level,combo,replay){const base=100+level*35+Math.min(combo,3)*15;return replay?Math.floor(base*.35):base;}
showResult=function(){
 const won=missionComplete();
 // records.js records the victory before invoking this wrapper.
 let repeat=false;try{repeat=(JSON.parse(localStorage.getItem('delaydoge.records')||'{}')[stage]?.wins||0)>1;}catch{}
 const reward=deliveryReward(stage,bestCombo,repeat);
 if(won&&!economyRewardPaid){economyRewardPaid=true;addCoins(reward);deliveries++;saveEconomy();}
 economyShow();
 if(won){$('resultText').textContent+=` · ${repeat?'مكافأة إعادة المرحلة':'مكافأة أول توصيل'} ${reward} ✦`;$('resultButton').textContent=stage===deliveryLevels.length?'العودة إلى المقر':'المرحلة التالية';}
 refreshEconomy();
};
const economyHome=home;home=function(){economyHome();refreshEconomy();};
function dailyDate(now=new Date()){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Riyadh',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);}
function dailyAvailable(){return localStorage.getItem('delaydoge.dailyClaim')!==dailyDate();}
const dailyButton=document.createElement('button');dailyButton.id='dailyGift';dailyButton.type='button';document.querySelector('.dispatch').appendChild(dailyButton);
const dailyNotice=document.createElement('p');dailyNotice.id='dailyNotice';dailyNotice.setAttribute('role','status');document.querySelector('.dispatch').appendChild(dailyNotice);
function refreshDaily(){dailyButton.disabled=!dailyAvailable();dailyButton.textContent=dailyAvailable()?'🎁 استلم هديتك اليومية · 100 ✦':'🎁 تم استلام هدية اليوم';if(!dailyAvailable()){const now=Date.now(),next=(Math.floor((now+10800000)/86400000)+1)*86400000-10800000,minutes=Math.ceil((next-now)/60000);dailyNotice.textContent=`الهدية القادمة بعد ${Math.floor(minutes/60)} ساعة و${minutes%60} دقيقة`;}}
function claimDaily(){if(!dailyAvailable()){refreshDaily();return false;}localStorage.setItem('delaydoge.dailyClaim',dailyDate());addCoins(100);refreshDaily();dailyNotice.textContent='أُضيفت 100 عملة إلى رصيدك!';return true;}
dailyButton.onclick=claimDaily;
const dailyStyle=document.createElement('style');dailyStyle.textContent='#dailyGift{margin-top:12px;width:100%;padding:10px;border:1px solid #f5d78e;border-radius:14px;background:linear-gradient(#fbc655,#d58b17);color:#3c270b;font-weight:800;box-shadow:0 3px #714b18}#dailyGift:disabled{background:#25475a;color:#bdd0db;border-color:#668797;box-shadow:none;cursor:default}#dailyNotice{font-size:12px;margin:8px 0 0;color:#ffe0a0}';document.head.appendChild(dailyStyle);
refreshDaily();setInterval(refreshDaily,60000);
const economyReset=reset;reset=function(){economyRewardPaid=false;economyReset();for(const type of ['rocket','stamp','shuffle']){const key='delaydoge.booster.'+type;const extra=Math.max(0,Number(localStorage.getItem(key)||0));if(extra){boosters[type]+=extra;localStorage.setItem(key,'0');}}render();refreshEconomy();};
