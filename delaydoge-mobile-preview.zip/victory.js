// Celebrate the recorded result without changing rewards or round state.
const victoryShow=showResult;
showResult=function(){
 victoryShow();
 const won=missionComplete(),card=$('result').querySelector('.result-card');
 card.classList.toggle('victory-card',won);
 $('victoryReward')?.remove();
 if(!won)return;
 $('resultEmoji').innerHTML='<div class="victory-hero"><img src="assets/delaydoge-cutout-v2.png" alt="DelayDoge يحتفل بوصول الشحنة"><span>وصلت… على توقيتي!</span></div>';
 const rating=roundStars(moves,stageMoves());
 resultStars.replaceChildren();
 for(let i=0;i<3;i++){
  const star=document.createElement('span');star.textContent=i<rating?'★':'☆';
  star.style.setProperty('--star-delay',`${i*150}ms`);resultStars.appendChild(star);
 }
 const rewardMatch=$('resultText').textContent.match(/ · (مكافأة إعادة المرحلة|مكافأة أول توصيل) (\d+) ✦/);
 if(rewardMatch){
  const reward=document.createElement('div');reward.id='victoryReward';reward.className='victory-reward';
  const label=document.createElement('small'),amount=document.createElement('strong');
  label.textContent=rewardMatch[1];amount.textContent=`+${rewardMatch[2]} ✦`;
  reward.append(label,amount);$('resultText').after(reward);
  $('resultText').textContent=$('resultText').textContent.replace(rewardMatch[0],'');
 }
};
