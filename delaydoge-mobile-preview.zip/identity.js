// A presentation layer: opening the game never starts or resets a saved round.
const leadPortrait=document.querySelector('.lobby-cat');
leadPortrait.src='assets/delaydoge-cutout-v2.png';
leadPortrait.alt='DelayDoge بطل مغامرة التوصيل';
document.querySelector('.dialogue').innerHTML='اهدأ… الطرد يفكّر.<br>متأخر، لكنه أسطوري!';
document.querySelector('.dispatch h1').textContent='مغامرة التوصيل مع DelayDoge';
document.querySelector('.brand').innerHTML='Delay<span>Doge</span>';
const opening=document.createElement('section');
opening.id='opening';
opening.setAttribute('aria-label','بداية مغامرة DelayDoge');
opening.innerHTML=`<div class="opening-content"><span class="opening-kicker">مغامرات البريد</span><div class="opening-logo" dir="ltr">DELAY<span>DOGE</span></div><p>كل شحنة لها مغامرة</p><div class="opening-portrait"><img src="assets/delaydoge-cutout-v2.png" alt="DelayDoge"><span class="opening-seal">بطل التوصيل</span></div><button id="enterAdventure" class="play-button">انطلق مع DelayDoge</button><small>طابق القطع · افتح الصناديق · أوصل الشحنة</small></div>`;
document.body.appendChild(opening);
document.body.classList.add('opening-visible');
$('enterAdventure').onclick=()=>{opening.remove();document.body.classList.remove('opening-visible');$('prepare').focus();};

// DelayDoge is the playable lead; Express Cat belongs to the story as his rival.
character='delaydoge';
localStorage.setItem('delaydoge.character',character);
$('courier').innerHTML='<option value="delaydoge">DelayDoge · متأخر، لكنه أسطوري · صاروخ إضافي</option>';
$('courier').disabled=true;
document.querySelector('label[for="courier"]').textContent='بطل الشحنة';
$('lobbyCast').textContent='الشخصيات';
$('teamCast').querySelector('span').textContent='الشخصيات';
$('cast').querySelector('h2').textContent='عالم DelayDoge';
$('cast').querySelector('p').textContent='بطل بارد الأعصاب… ومنافس لا يعرف الانتظار.';
renderCast=function(){
 $('castGrid').innerHTML=`<article class="story-character"><img src="assets/delaydoge-cutout-v2.png" alt="DelayDoge"><b>DelayDoge</b><strong>البطل الأسطوري</strong><p>كل شحنة لها مغامرة. القهوة أولًا، والتوصيل يأتي… في النهاية.</p></article><article class="story-character rival"><img src="assets/expresscat-cutout-v2.png" alt="Express Cat"><b>Express Cat</b><strong>المنافس السريع</strong><p>«وصلت الطلب قبل أن تصحى!» السرعة عنده كل شيء، والتسرّع يوقعه في المشاكل.</p></article>`;
};
const storyResult=showResult;
showResult=function(){
 storyResult();
 const won=missionComplete();
 $('resultTitle').textContent=won?(stage===deliveryLevels.length?'انتهت الرحلة… ووصلت الأسطورة!':'متأخر، لكنه أسطوري!'):'الطرد أخذ استراحة…';
 $('resultText').textContent+=(won?' · DelayDoge: التأخير كان جزءًا من الخطة.':' · DelayDoge: اهدأ، القهوة لم تنتهِ بعد. العميلة تطلب المدير!');
};
// Update the restored round's presentation without resetting its board or tools.
render();
