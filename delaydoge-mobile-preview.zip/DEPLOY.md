# DelayDoge postal game preview

Deploy this directory as a Render Static Site.

- Repository: salum202-coder/delaydoge-game
- Branch: postal-mobile-preview
- Root directory: postal-preview
- Build command: echo "Static game ready"
- Publish directory: .

Only this directory is published. The existing backend, database and Telegram integration are not required for this preview. Progress is stored in the browser on each device.
