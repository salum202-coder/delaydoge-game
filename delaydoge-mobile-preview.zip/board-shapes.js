// Empty cells split gravity into independent vertical lanes. Rockets cross gaps.
const routeGaps=[
 [0,7,8,15],
 [0,1,6,7,8,15,56,57,62,63],
 [0,1,6,7,8,15,27,28,35,36,48,55,56,57,62,63],
 [0,1,2,7,8,9,15,16,23,40,48,56,57,58],
 [0,1,6,7,8,15,27,28,35,36,59,60],
 [3,4,11,12,19,20,43,44,51,52,59,60],
 [0,7,8,15,56,63],
 [16,23,24,25,30,31,32,33,38,39,40,47],
 [3,4,11,12,27,28,35,36,51,52,59,60],
 [0,1,2,3,4,8,9,10,11,16,17,18,24,25,32,33,40,41,42,48,49,50,51,56,57,58,59,60]
];
const isGap=i=>routeGaps[stage-1].includes(i);
const authoredRouteGaps=routeGaps.map(gaps=>[...gaps]);
const shapedMakeGrid=makeGrid;
makeGrid=function(){routeGaps[stage-1]=[...authoredRouteGaps[stage-1]];shapedMakeGrid();for(const i of routeGaps[stage-1]){grid[i]=null;delete specials[i];}};
const shapedRender=render;
render=function(){shapedRender();for(const i of routeGaps[stage-1]){const tile=$('board').children[i];tile.className='tile board-gap';tile.innerHTML='';tile.disabled=true;tile.setAttribute('aria-hidden','true');tile.style.background='none';tile.style.transform='none';}};
const shapedPick=pick;pick=function(i){if(!isGap(i))shapedPick(i);};
const shapedPreview=previewMove;previewMove=function(a,b){return isGap(a)||isGap(b)?[]:shapedPreview(a,b).filter(i=>!isGap(i));};
const shapeStyle=document.createElement('style');shapeStyle.textContent=`.board .board-gap{visibility:hidden;pointer-events:none}.board-wrap{background:transparent!important;border-color:transparent!important;box-shadow:none!important;padding:7px}.board .tile:not(.board-gap){box-shadow:0 0 0 2px #8fbdcf,0 3px 0 2px #0a263a}.board{gap:4px}`;document.head.appendChild(shapeStyle);
reset();
