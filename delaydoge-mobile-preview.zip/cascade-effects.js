// Record engine steps, then replay their visuals before presenting the result.
let effectSteps=null;
const captureBoard=()=>({grid:[...grid],specials:{...specials},crates:new Set(crates),locks:{...customsHealth}});
const effectClear=clearTiles;
clearTiles=function(indices,combo){const before=captureBoard(),hit=expandedBlast(indices);effectClear(indices,combo);if(effectSteps)effectSteps.push({type:'clear',before,after:captureBoard(),hit});};
const effectDrop=breakDrop;
breakDrop=function(){const before=captureBoard();effectDrop();if(effectSteps)effectSteps.push({type:'drop',before,after:captureBoard()});};
function paintFrame(state){[...$('board').children].forEach((tile,i)=>{if(isGap(i))return;tile.style.transform='';tile.style.opacity=state.grid[i]===null&&!state.crates.has(i)?'0':'1';const special=state.specials[i];tile.innerHTML=sprite(state.crates.has(i)?7:special==='🌟'?6:special?5:state.grid[i]??0);tile.classList.toggle('crate',state.crates.has(i));tile.classList.toggle('special',!!special);if(special==='vertical')tile.style.transform='rotate(90deg)';});}
async function beam(index,vertical){
 const board=$('board'),r=board.getBoundingClientRect(),t=board.children[index].getBoundingClientRect(),beam=document.createElement('i');
 Object.assign(beam.style,{position:'absolute',pointerEvents:'none',zIndex:6,background:'#fff8bb',boxShadow:'0 0 14px 5px #ffbb42',borderRadius:'12px',left:vertical?(t.left-r.left+t.width/2-3)+'px':'0',top:vertical?'0':(t.top-r.top+t.height/2-3)+'px',width:vertical?'6px':'100%',height:vertical?'100%':'6px'});
 board.appendChild(beam);try{await animateTile(beam,[{opacity:0,transform:vertical?'scaleY(.1)':'scaleX(.1)'},{opacity:1,transform:'scale(1)',offset:.3},{opacity:.8,filter:'brightness(1.6)',offset:.55},{opacity:0,transform:vertical?'scaleX(.2)':'scaleY(.2)'}],280);}finally{beam.remove();}
}
async function postalSpark(index,gold=false){
 const board=$('board'),tile=board.children[index];if(!tile||reduced())return;
 const r=board.getBoundingClientRect(),t=tile.getBoundingClientRect(),bits=[];
 try{
  const work=[];
  for(let n=0;n<6;n++){
   const bit=document.createElement('i'),angle=n*Math.PI/3,distance=t.width*(gold?.8:.55);
   bit.className='postal-spark';
   Object.assign(bit.style,{left:`${t.left-r.left+t.width/2}px`,top:`${t.top-r.top+t.height/2}px`,background:gold?'#ffda72':'#c9a2ff'});
   board.appendChild(bit);bits.push(bit);
   work.push(animateTile(bit,[{translate:'-50% -50%',scale:'.4',opacity:1},{translate:`${Math.cos(angle)*distance}px ${Math.sin(angle)*distance}px`,scale:'1',opacity:.85,offset:.5},{translate:`${Math.cos(angle)*distance*1.2}px ${Math.sin(angle)*distance*1.2+8}px`,scale:'.2',opacity:0}],300));
  }
  await Promise.all(work);
 }finally{bits.forEach(bit=>bit.remove());}
}
async function replayStep(step){
 paintFrame(step.before);
 if(step.type==='clear'){
  const work=[];
  for(const i of step.hit){const kind=step.before.specials[i];if(kind&&kind!=='🌟')work.push(beam(i,kind==='vertical'));const t=$('board').children[i];if(!isGap(i))work.push(animateTile(t,[{filter:'brightness(1)',scale:'1'},{filter:'brightness(2)',scale:'1.15'},{opacity:0,scale:'.2'}],230));}
  for(const i of step.before.crates){
   if(!step.after.crates.has(i)){
    work.push(postalSpark(i,true));
    work.push(animateTile($('board').children[i],[{translate:'0px',rotate:'0deg'},{translate:'-5px',rotate:'-9deg'},{translate:'5px',rotate:'9deg'},{opacity:0,scale:'.4',rotate:'18deg'}],270));
   }else if(step.after.locks[i]<step.before.locks[i]){
    work.push(postalSpark(i,true));
    work.push(animateTile($('board').children[i],[{rotate:'0deg',filter:'brightness(1)'},{rotate:'-7deg',filter:'brightness(1.8)'},{rotate:'7deg'},{rotate:'0deg',filter:'brightness(1)'}],240));
   }
  }
  for(const i of step.hit)if(step.before.specials[i]==='🌟')work.push(postalSpark(i));
  await Promise.all(work);paintFrame(step.after);
 }else{
  paintFrame(step.after);const work=[],cell=$('board').getBoundingClientRect().height/8;
  for(let x=0;x<8;x++){let bottom=7;while(bottom>=0){if(isGap(bottom*8+x)||step.before.crates.has(bottom*8+x)){bottom--;continue;}let top=bottom;while(top>=0&&!isGap(top*8+x)&&!step.before.crates.has(top*8+x))top--;const sources=[];for(let y=bottom;y>top;y--)if(step.before.grid[y*8+x]!==null)sources.push(y);for(let y=bottom;y>top;y--){const source=sources.length?sources.shift():top;const distance=(y-source)*cell;if(distance)work.push(animateTile($('board').children[y*8+x],[{translate:`0 -${distance}px`,opacity:.3},{translate:'0 3px',opacity:1,offset:.8},{translate:'0 -1px',offset:.93},{translate:'0 0',opacity:1}],Math.min(360,160+distance)));}bottom=top-1;}}
  await Promise.all(work);
 }
}
async function runEffects(action){
 if(animating)return;
 animating=true;document.querySelector('.app').classList.add('resolving');
 const before=captureBoard(),savedRender=render,savedResult=showResult;let resultPending=false;
 effectSteps=[];
 try{
  render=()=>{};showResult=()=>{resultPending=true;ended=true;};
  try{action();}finally{render=savedRender;showResult=savedResult;}
  const steps=effectSteps;effectSteps=null;
  paintFrame(before);
  if(!reduced())for(const step of steps)await replayStep(step);
  render();if(resultPending)showResult();
 }finally{effectSteps=null;render=savedRender;showResult=savedResult;animating=false;document.querySelector('.app').classList.remove('resolving');}
}
// basePick is the synchronous shaped engine captured by play-screen.js.
pick=async function(i){if(animating||ended||moves<=0||isGap(i)||crates.has(i))return;if(selected===null||!adjacent(selected,i)){basePick(i);return;}const a=selected,first=$('board').children[a],second=$('board').children[i],r=first.getBoundingClientRect(),s=second.getBoundingClientRect();animating=true;try{await Promise.all([animateTile(first,[{translate:'0 0'},{translate:`${s.left-r.left}px ${s.top-r.top}px`}],160),animateTile(second,[{translate:'0 0'},{translate:`${r.left-s.left}px ${r.top-s.top}px`}],160)]);}finally{animating=false;}await runEffects(()=>basePick(i));};
const effectsBooster=useBooster;useBooster=type=>{if(!ended&&boosters[type])return runEffects(()=>effectsBooster(type));};
