const clearerGoalsRender=render;
render=function(){clearerGoalsRender();for(const [id,label] of [['hudMail',lostDeliveryMode?'طرد':'بريد'],['hudCrates','صناديق']]){const count=$(id),host=count.parentElement;if(host.querySelector('.goal-kind'))continue;const kind=document.createElement('small');kind.className='goal-kind';kind.textContent=label;host.appendChild(kind);}};
async function deliveryImpact(index,caption){
 if(reduced())return;
 const board=$('board'),tile=board.children[index];if(!tile||isGap(index))return;
 const r=board.getBoundingClientRect(),t=tile.getBoundingClientRect(),x=t.left-r.left+t.width/2,y=t.top-r.top+t.height/2;
 const ring=document.createElement('i');ring.className='impact-ring';ring.style.left=x+'px';ring.style.top=y+'px';board.appendChild(ring);
 const work=[animateTile(ring,[{scale:'.3',opacity:.9},{scale:'2.4',opacity:0}],260)];
 let text;if(caption){text=document.createElement('span');text.className='match-score';text.textContent=caption;text.style.left=x+'px';text.style.top=y+'px';board.appendChild(text);work.push(animateTile(text,[{translate:'0 0',opacity:1},{translate:'0 -32px',opacity:0}],440));}
 try{await Promise.all(work);}finally{ring.remove();text?.remove();}
}
const clearerReplay=replayStep;
replayStep=async function(step){
 if(step.type!=='clear')return clearerReplay(step);
 const cells=step.hit.filter(i=>!isGap(i)&&step.before.grid[i]!==null&&!step.before.crates.has(i));
 const center=cells[Math.floor(cells.length/2)];
 const opened=[...step.before.crates].filter(i=>!step.after.crates.has(i));
 const replay=clearerReplay(step);const impacts=[];if(center!==undefined)impacts.push(deliveryImpact(center,`${cells.length} قطع!`));
 for(const i of opened.slice(0,4))impacts.push(deliveryImpact(i));
 return Promise.all([replay,...impacts]);
};
const clearerBooster=useBooster;
useBooster=function(type){if(!animating&&!ended&&boosters[type]>0){const wrap=document.querySelector('.board-wrap');wrap.classList.remove('booster-flash');void wrap.offsetWidth;wrap.classList.add('booster-flash');setTimeout(()=>wrap.classList.remove('booster-flash'),400);}return clearerBooster(type);};
render();

