function legalMoves(){
 const found=[];
 for(let a=0;a<64;a++){
  if(isGap(a)||crates.has(a)||grid[a]===5)continue;
  for(const b of [a+1,a+8]){
   if(b>=64||!adjacent(a,b)||isGap(b)||crates.has(b)||grid[b]===5)continue;
   if(specials[a]||specials[b]){found.push([a,b]);continue;}
   swapTiles(a,b);const matches=findMatches();swapTiles(a,b);
   if(matches.includes(a)||matches.includes(b))found.push([a,b]);
  }
 }
 return found;
}
function ensurePlayable(){
 if(ended||moves<=0||legalMoves().length)return false;
 const cells=grid.map((c,i)=>({c,i,s:specials[i]})).filter(t=>!isGap(t.i)&&!crates.has(t.i)&&t.c!==5);
 const original=grid.slice(),oldSpecials={...specials};
 for(let attempt=0;attempt<300;attempt++){
  const items=cells.map(t=>({c:t.c,s:t.s}));
  for(let i=items.length-1;i>0;i--){const j=rand(i+1);[items[i],items[j]]=[items[j],items[i]];}
  specials={};cells.forEach((t,n)=>{grid[t.i]=items[n].c;if(items[n].s)specials[t.i]=items[n].s;});
  if(!findMatches().length&&legalMoves().length){selected=null;return true;}
 }
 // Extremely constrained colour inventories may need fresh ordinary pieces.
 for(let attempt=0;attempt<1000;attempt++){
  specials={...oldSpecials};
  for(const {i} of cells){grid[i]=rand(5);while(i%8>=2&&grid[i]===grid[i-1]&&grid[i]===grid[i-2]||i>=16&&grid[i]===grid[i-8]&&grid[i]===grid[i-16])grid[i]=rand(5);}
  if(!findMatches().length&&legalMoves().length){selected=null;return true;}
 }
 grid=original;specials=oldSpecials;return false;
}
const assistNotice=document.createElement('div');assistNotice.className='assist-notice';assistNotice.setAttribute('role','status');document.querySelector('.board-wrap').after(assistNotice);
let noticeTimer;
function announceBoard(text){assistNotice.textContent=text;clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>assistNotice.textContent='',2600);}
function drawBoardOutline(){
 const board=$('board');let frame=board.parentElement.querySelector('.board-outline');
 if(!frame){frame=document.createElementNS('http://www.w3.org/2000/svg','svg');frame.classList.add('board-outline');frame.setAttribute('viewBox','0 0 800 800');frame.setAttribute('aria-hidden','true');board.before(frame);}
 let fill='',edge='';
 for(let i=0;i<64;i++)if(!isGap(i)){
  const x=i%8*100,y=Math.floor(i/8)*100;
  fill+=`M${x} ${y}h100v100h-100Z`;
  if(i<8||isGap(i-8))edge+=`M${x} ${y}h100`;
  if(i>=56||isGap(i+8))edge+=`M${x} ${y+100}h100`;
  if(i%8===0||isGap(i-1))edge+=`M${x} ${y}v100`;
  if(i%8===7||isGap(i+1))edge+=`M${x+100} ${y}v100`;
 }
 frame.innerHTML=`<path d="${fill}" fill="#153b54"/><path d="${edge}" fill="none" stroke="#081e30" stroke-width="15" stroke-linejoin="round"/><path d="${edge}" fill="none" stroke="#acd3df" stroke-width="7" stroke-linecap="round"/>`;
}
const assistRender=render;
render=function(){const mixed=ensurePlayable();assistRender();drawBoardOutline();if(mixed)announceBoard('لا توجد حركة متاحة؛ أعدنا ترتيب القطع مجانًا.');};
$('hint').onclick=()=>{
 if(ended)return;
 const mixed=ensurePlayable();if(mixed)render();
 const pair=legalMoves()[0];
 if(!pair){announceBoard('لا يوجد تبديل متاح؛ استخدم إحدى الأدوات.');return;}
 for(const i of pair)$('board').children[i].classList.add('hint');
 announceBoard('بدّل القطعتين المضيئتين.');
 setTimeout(()=>{for(const t of $('board').children)t.classList.remove('hint');},1800);
};
const assistStyle=document.createElement('style');assistStyle.textContent=`.board-wrap{position:relative}.board-outline{position:absolute;inset:7px;width:calc(100% - 14px);height:calc(100% - 14px);overflow:visible;pointer-events:none}.board{position:relative;gap:0!important}.board .tile{width:calc(100% - 4px);margin:2px;box-shadow:none!important;border-radius:7px}.board .hint{outline:3px solid #fff1a2;z-index:2;animation:pulse .5s infinite alternate}.assist-notice{position:absolute;bottom:150px;left:5%;right:5%;text-align:center;background:#102f48ed;color:#ffdf91;border-radius:12px;font-size:12px;z-index:4;pointer-events:none}.assist-notice:not(:empty){padding:10px;border:1px solid #dbb774}`;document.head.appendChild(assistStyle);
render();
