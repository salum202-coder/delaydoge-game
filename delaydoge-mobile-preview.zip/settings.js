let soundEnabled=localStorage.getItem('delaydoge.sound')!=='off';
let reducedMotion=localStorage.getItem('delaydoge.motion')==='reduced';
const settingsTone=tone;
tone=function(...args){if(soundEnabled)settingsTone(...args);};
function applySettings(){document.body.classList.toggle('reduce-motion',reducedMotion);}
const settingsPanel=document.createElement('div');
settingsPanel.className='result';settingsPanel.hidden=true;
settingsPanel.innerHTML='<div class="result-card settings-card"><button class="close-button" aria-label="إغلاق الإعدادات">×</button><h2>إعدادات اللعبة</h2><label class="setting-row"><span>المؤثرات الصوتية</span><input id="soundSetting" type="checkbox"></label><label class="setting-row"><span>تقليل الحركة</span><input id="motionSetting" type="checkbox"></label><p>تُحفظ اختياراتك تلقائيًا</p></div>';
document.body.appendChild(settingsPanel);
function openSettings(){document.getElementById('soundSetting').checked=soundEnabled;document.getElementById('motionSetting').checked=reducedMotion;settingsPanel.hidden=false;settingsPanel.querySelector('.close-button').focus();}
let settingsOpener=null;
function closeSettings(){settingsPanel.hidden=true;settingsOpener?.focus();}
for(const host of [document.querySelector('.lobby-nav'),document.querySelector('.top')]){const button=document.createElement('button');button.type='button';button.className='settings-button';button.setAttribute('aria-label','إعدادات اللعبة');button.innerHTML='⚙<span>الإعدادات</span>';button.onclick=()=>{settingsOpener=button;openSettings();};host.appendChild(button);}
settingsPanel.querySelector('.close-button').onclick=closeSettings;
settingsPanel.onclick=e=>{if(e.target===settingsPanel)closeSettings();};
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!settingsPanel.hidden)closeSettings();});
document.getElementById('soundSetting').onchange=e=>{soundEnabled=e.target.checked;localStorage.setItem('delaydoge.sound',soundEnabled?'on':'off');if(soundEnabled)tone(520);};
document.getElementById('motionSetting').onchange=e=>{reducedMotion=e.target.checked;localStorage.setItem('delaydoge.motion',reducedMotion?'reduced':'full');applySettings();};
const settingsStyle=document.createElement('style');settingsStyle.textContent='.settings-card{position:relative}.setting-row{display:flex;justify-content:space-between;align-items:center;padding:18px 0;border-bottom:1px solid #ffffff22}.setting-row input{width:24px;height:24px;accent-color:#8ddd35}.settings-card p{font-size:12px;margin-top:18px}.top .settings-button{display:block!important;font-size:18px}.top .settings-button span{display:none}.lobby-nav .settings-button{font-size:23px}.reduce-motion *{animation:none!important;transition:none!important;scroll-behavior:auto!important}';document.head.appendChild(settingsStyle);
applySettings();
const helpButton=document.createElement('button');helpButton.type='button';helpButton.textContent='كيف ألعب؟';helpButton.className='help-button';settingsPanel.querySelector('.settings-card').appendChild(helpButton);
const helpPanel=document.createElement('div');helpPanel.className='result';helpPanel.hidden=true;
helpPanel.innerHTML=`<div class="result-card help-card"><button class="close-button" aria-label="إغلاق دليل اللعب">×</button><span class="badge">دليل المندوب</span><h2>كيف ألعب؟</h2><div class="help-example" aria-label="طابق ثلاث قطع متشابهة">${sprite(1)}${sprite(1)}${sprite(1)}</div><ol><li><b>بدّل قطعتين متجاورتين</b><p>اضغط القطعة ثم جارتها لتكوين صف أو عمود من ثلاث قطع متشابهة. التبديل الذي لا يصنع تطابقًا يعود دون استهلاك حركة.</p></li><li><b>أكمل أهداف الشحنة</b><p>راقب الأعداد أعلى اللوحة. اكسر الصناديق بمطابقة القطع بجانبها أو باستخدام الأدوات، وأكمل الأهداف قبل نفاد الحركات.</p></li><li><b>اصنع قطعًا خاصة</b><p>مطابقة أربع قطع تصنع صاروخًا، وخمس قطع تصنع نجمة تفجّر مساحة حولها. بدّل القطعة الخاصة مع جارتها لتفعيلها.</p></li></ol><div class="help-tools"><p><b>الصاروخ:</b> يمسح صف القطعة المحددة. إذا لم تحدد قطعة، يختار صفًا عشوائيًا.</p><p><b>الختم:</b> يزيل صندوقين مختومين، أو ما تبقى منهما.</p><p><b>التحويلة:</b> تعيد ترتيب القطع. الأدوات لا تستهلك حركات.</p><p><b>إظهار تلميح:</b> يضيء قطعتين يمكنك تبديلهما.</p></div><button class="help-return">فهمت، جاهز للتوصيل!</button></div>`;
document.body.appendChild(helpPanel);
helpButton.onclick=()=>{settingsPanel.hidden=true;helpPanel.hidden=false;helpPanel.querySelector('.close-button').focus();};
function closeHelp(){helpPanel.hidden=true;openSettings();helpButton.focus();}
helpPanel.querySelector('.close-button').onclick=closeHelp;helpPanel.querySelector('.help-return').onclick=closeHelp;helpPanel.onclick=e=>{if(e.target===helpPanel)closeHelp();};document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!helpPanel.hidden){e.stopImmediatePropagation();closeHelp();}},true);
const helpStyle=document.createElement('style');helpStyle.textContent='.help-card{position:relative;text-align:right}.help-card h2{text-align:center}.help-example{display:flex;justify-content:center;gap:8px;margin:18px 0}.help-example .sprite{width:48px;height:48px;display:block;background-image:url(assets/postal-atlas-v1.png)}.help-card ol{padding-inline-start:22px;font-size:14px}.help-card li{margin-bottom:16px}.help-card p{font-size:13px;margin:6px 0 12px;line-height:1.8}.help-card b{color:#ffda84}.help-tools{padding:12px;background:#ffffff0a;border-radius:14px}.help-button,.help-return{margin-top:16px;width:100%;background:#078ed2}';document.head.appendChild(helpStyle);
