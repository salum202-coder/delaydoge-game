// Complaints stick to board cells, not to the pieces falling through them.
const complaintCells=[10,13,18,21,26,37,42,53];
const complaintsMake=makeGrid;
makeGrid=function(){complaintsMake();complaints=new Set(stage===5?complaintCells:[]);};
const complaintsClear=clearTiles;
clearTiles=function(indices,combo=1){
 const hit=expandedBlast(indices);
 complaintsClear(indices,combo);
 if(stage===5)for(const i of hit)if(complaints.delete(i))score+=15;
};
const complaintsRender=render;
render=function(){
 complaintsRender();if(stage!==5)return;
 for(const i of complaints){const tile=$('board').children[i];tile.insertAdjacentHTML('beforeend','<span class="complaint-paper" aria-hidden="true">!</span>');tile.setAttribute('aria-label',tile.getAttribute('aria-label')+'، عليها شكوى: طابق هذه القطعة لإزالتها');}
 $('progressText').textContent=`البريد ${Math.min(collected,targetParcels())}/${targetParcels()} · الصناديق ${broken}/${targetCrates()} · الشكاوى ${complaints.size}`;
 $('progress').style.width=((Math.min(collected/targetParcels(),1)+Math.min(broken/targetCrates(),1)+(1-complaints.size/complaintCells.length))/3*100)+'%';
};
deliveryLevels[4].name='شكاوى Angry Karen';
deliveryLevels[4].note='وين طلبي؟ أريد المدير! أزل أوراق ! بمطابقة القطعة المغطاة أو بالصاروخ، واجمع البريد وافتح الصناديق. يجب إزالة جميع الشكاوى للفوز. التحويلة لا تزيل الأوراق.';
const complaintsPrepare=prepare;
prepare=function(){complaintsPrepare();if(stage===5)$('preparation').querySelector('.included-tools').textContent='Angry Karen: أريد المدير! · 8 شكاوى إضافية يجب حلّها.';};
