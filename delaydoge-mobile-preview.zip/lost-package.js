// Value 5 is a mission parcel. It falls with gravity but cannot match or explode.
const parcelMake=makeGrid;
makeGrid=function(){parcelMake();lostDeliveryMode=stage===1;if(lostDeliveryMode)grid[3]=5;};
const parcelTarget=targetParcels,parcelCrates=targetCrates;
targetParcels=()=>lostDeliveryMode?1:parcelTarget();
targetCrates=()=>lostDeliveryMode?0:parcelCrates();
const parcelDrop=breakDrop;
breakDrop=function(){parcelDrop();if(lostDeliveryMode&&grid[59]===5){grid[59]=rand(5);collected=1;score+=100;}};
const parcelRender=render;
render=function(){
 parcelRender();
 if(!lostDeliveryMode)return;
 for(let i=0;i<64;i++)if(grid[i]===5){const tile=$('board').children[i];tile.innerHTML=sprite(1)+'<span class="lost-tag">؟</span>';tile.classList.add('lost-parcel');tile.setAttribute('aria-label','الطرد الضائع: طابق القطع تحته لإنزاله');}
 $('board').children[59].classList.add('delivery-exit');
 $('hudCrates').parentElement.hidden=true;
 $('progressText').textContent=collected?'وصل الطرد… أخيرًا!':'أنزل الطرد ؟ إلى المخرج ↓';
 $('progress').style.width=collected?'100%':'0%';
};
const normalParcelRender=render;
render=function(){normalParcelRender();if(!lostDeliveryMode)$('hudCrates').parentElement.hidden=false;};
const parcelPrepare=prepare;
prepare=function(){parcelPrepare();if(stage===1){$('prepTitle').textContent='1 · العنوان غلط… مرة ثانية';$('preparation').querySelector('.prep-card > p').textContent='طابق القطع تحت الطرد ؟ حتى ينزل إلى المخرج ↓. الصناديق عقبات، ولا تحتاج إلى فتحها كلها.';$('prepParcels').textContent='1';$('prepParcels').nextElementSibling.textContent='طرد ضائع للتوصيل';$('prepCrates').parentElement.hidden=true;}else{$('prepParcels').nextElementSibling.textContent='قطع بريد';$('prepCrates').parentElement.hidden=false;}};
const parcelPick=pick;
pick=async function(i){if(grid[i]===5){announceBoard('الطرد لا يُبدّل. طابق القطع تحته ليهبط إلى المخرج ↓.');return;}return parcelPick(i);};
const parcelFrame=paintFrame;
paintFrame=function(state){parcelFrame(state);state.grid.forEach((c,i)=>{if(c===5){$('board').children[i].innerHTML=sprite(1)+'<span class="lost-tag">؟</span>';}});};
