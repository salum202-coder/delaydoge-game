const stageStories={
 1:{name:'Lost Package',icon:'📦',role:'الطرد الضائع',line:'العنوان غلط… مرة ثانية.',reply:'اهدأ، الطرد يفكّر.'},
 3:{name:'Customs Boss',image:'assets/customs-boss-v1.png',role:'حارس الجمارك',line:'وين الأوراق؟ والختم ناقص!',reply:'حتى تأخيري يحتاج تصريح؟'},
 4:{name:'Traffic Raccoon',image:'assets/traffic-raccoon-v1.png',role:'عامل الفوضى',line:'الطريق مقفل. يمكن للأبد.',reply:'ممتاز… وقت إضافي للقهوة.'},
 5:{name:'Angry Karen',image:'assets/angry-karen-v1.png',role:'ملكة الشكاوى',line:'وين طلبي؟ أريد المدير!',reply:'المدير متأخر أيضًا.'},
 8:{name:'Express Cat',image:'assets/expresscat-cutout-v2.png',role:'المنافس السريع',line:'وصلت الطلب قبل ما تصحى!',reply:'أنا أوصل… بدخول أسطوري.'}
};
const storyDock=document.createElement('button');
storyDock.id='storyDock';storyDock.hidden=true;storyDock.setAttribute('aria-label','شاهد حوار المرحلة');
document.querySelector('.play-hud').after(storyDock);
const storyPanel=document.createElement('div');storyPanel.id='storyPanel';storyPanel.className='result';storyPanel.hidden=true;
storyPanel.innerHTML='<div class="result-card scene-card"><button class="close-button" id="closeStory" aria-label="إغلاق الحوار">×</button><span class="badge">فوضى التوصيل</span><h2 id="sceneName"></h2><div id="scenePortrait"></div><p id="sceneLine"></p><div class="doge-reply"><img src="assets/delaydoge-cutout-v2.png" alt="DelayDoge"><p id="sceneReply"></p></div><button id="continueStory" class="play-button">خلّهم ينتظرون… نكمل!</button></div>';
document.body.appendChild(storyPanel);
storyDock.onclick=()=>{const scene=stageStories[stage];if(!scene)return;$('sceneName').textContent=scene.name+' · '+scene.role;$('scenePortrait').innerHTML=scene.image?`<img src="${scene.image}" alt="${scene.name}">`:`<span class="scene-icon" aria-hidden="true">${scene.icon}</span>`;$('sceneLine').textContent='«'+scene.line+'»';$('sceneReply').textContent='DelayDoge: '+scene.reply;storyPanel.hidden=false;$('closeStory').focus();};
const closeStory=()=>{storyPanel.hidden=true;storyDock.focus();};
$('closeStory').onclick=closeStory;$('continueStory').onclick=closeStory;
storyPanel.onclick=e=>{if(e.target===storyPanel)closeStory();};
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!storyPanel.hidden)closeStory();});
const scenesRender=render;
render=function(){scenesRender();const scene=stageStories[stage];storyDock.hidden=!scene;if(scene)storyDock.innerHTML=`${scene.image?`<img src="${scene.image}" alt="">`:`<span aria-hidden="true">${scene.icon}</span>`}<span><b>${scene.name}</b><small>${scene.line}</small></span><span aria-hidden="true">💬</span>`;};
const scenesCast=renderCast;
renderCast=function(){scenesCast();for(const n of [3,4,5]){const scene=stageStories[n],card=document.createElement('article');card.className='story-character';card.innerHTML=`<img src="${scene.image}" alt="${scene.name}"><b>${scene.name}</b><strong>${scene.role}</strong><p>${scene.line}</p>`;$('castGrid').appendChild(card);}};
render();
