// A swipe uses the same pick path as two taps, including move validation and saves.
function swipeDirection(dx,dy,threshold=18){
 if(Math.max(Math.abs(dx),Math.abs(dy))<threshold)return null;
 return Math.abs(dx)>Math.abs(dy)?{x:Math.sign(dx),y:0}:{x:0,y:Math.sign(dy)};
}
const touchBoard=$('board');
let boardGesture=null,suppressBoardClickUntil=0;
touchBoard.addEventListener('pointerdown',event=>{
 if(!event.isPrimary||event.button!==0||animating||ended)return;
 const tile=event.target.closest('.tile');if(!tile)return;
 const index=[...touchBoard.children].indexOf(tile);
 if(index<0||isGap(index)||crates.has(index)||grid[index]===5)return;
 boardGesture={id:event.pointerId,index,x:event.clientX,y:event.clientY};
 touchBoard.setPointerCapture(event.pointerId);
});
touchBoard.addEventListener('pointerup',event=>{
 const gesture=boardGesture;if(!gesture||gesture.id!==event.pointerId)return;
 boardGesture=null;
 const direction=swipeDirection(event.clientX-gesture.x,event.clientY-gesture.y);
 if(!direction)return;
 suppressBoardClickUntil=performance.now()+500;
 if(animating||ended)return;
 const tile=touchBoard.children[gesture.index],start=tile.getBoundingClientRect();
 const cx=start.left+start.width/2,cy=start.top+start.height/2;
 let target=-1;
 [...touchBoard.children].slice(0,64).forEach((candidate,index)=>{
  if(!adjacent(gesture.index,index)||isGap(index)||crates.has(index)||grid[index]===5)return;
  const rect=candidate.getBoundingClientRect(),dx=rect.left+rect.width/2-cx,dy=rect.top+rect.height/2-cy;
  if(direction.x?Math.sign(dx)===direction.x&&Math.abs(dy)<start.height/2:Math.sign(dy)===direction.y&&Math.abs(dx)<start.width/2)target=index;
 });
 if(target<0)return;
 selected=gesture.index;pick(target);
});
const cancelBoardGesture=()=>{boardGesture=null;};
touchBoard.addEventListener('pointercancel',cancelBoardGesture);
touchBoard.addEventListener('lostpointercapture',cancelBoardGesture);
touchBoard.addEventListener('click',event=>{
 if(performance.now()<suppressBoardClickUntil){event.preventDefault();event.stopImmediatePropagation();}
},true);
